# Execute
```bash
docker compose up -d
```

# Docker Images
- https://hub.docker.com/r/bitnami/kafka

# Tools
- https://www.kafkatool.com

# YouTube
- PT: https://youtu.be/B8jUaFPu7x8
- EN: https://youtu.be/8U15Cu3ItyA
